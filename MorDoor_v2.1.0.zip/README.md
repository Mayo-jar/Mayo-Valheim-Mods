# MorDoor

  * You can now simply walk through "more doors"
      * any two doors that are adjacent to, and opposite each other will open in sync

## Installation

### Manual

  * Un-zip `MorDoor.dll` to your `/Valheim/BepInEx/plugins/` folder.

### Thunderstore (manual install)

  * Go to Settings > Import local mod > Select `MorDoor_v2.1.0.zip`.
  * Click "OK/Import local mod" on the pop-up for information.

## Changelog
## 2.1.0

  * MorDoor will now claim ownership on all doors being opened (for multiplayer servers)
  * Lag related bugfixes

## 2.0.0

  * Changed the main logic for checking the status of doors, now ANY object with a door component will function as long as it is the same relative width as a normal door or gate
  * there are now MORE DOORS in MorDoor!... I'll see myself out

## 1.1.0

  * Added Config enabler/disabler along with a bugfix for doors in different states

## 1.0.0

  * Initial release.