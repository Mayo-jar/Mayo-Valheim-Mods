# MorDoor

  * Doors and Chests will open faster on multiplayer
## Installation

### Manual

  * Un-zip `WD40.dll` to your `/Valheim/BepInEx/plugins/` folder.

### Thunderstore (manual install)

  * Go to Settings > Import local mod > Select `WD40_v1.0.0.zip`.
  * Click "OK/Import local mod" on the pop-up for information.

## Changelog

## 1.0.0

  * Initial release.