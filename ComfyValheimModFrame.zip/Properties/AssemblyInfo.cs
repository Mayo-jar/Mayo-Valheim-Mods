﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("$safeprojectname$")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("$safeprojectname$")]
[assembly: AssemblyCopyright("Copyright © 2023")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]
[assembly: Guid("$guid1$")]

[assembly: AssemblyVersion($safeprojectname$.$safeprojectname$.PluginVersion)]
[assembly: AssemblyFileVersion($safeprojectname$.$safeprojectname$.PluginVersion)]