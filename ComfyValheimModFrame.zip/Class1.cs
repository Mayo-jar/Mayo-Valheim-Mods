﻿using System.Reflection;

using BepInEx;

using HarmonyLib;

namespace $safeprojectname$ {
  [BepInPlugin(PluginGuid, PluginName, PluginVersion)]
  public sealed class $safeitemname$ : BaseUnityPlugin {
    public const string PluginGuid = "comfy.valheim.modname";
    public const string PluginName = "$safeprojectname$";
    public const string PluginVersion = "1.0.0";

    Harmony _harmony;

    void Awake() {
      _harmony = Harmony.CreateAndPatchAll(Assembly.GetExecutingAssembly(), harmonyInstanceId: PluginGuid);
    }

    void OnDestroy() {
      _harmony?.UnpatchSelf();
    }
  }
}
